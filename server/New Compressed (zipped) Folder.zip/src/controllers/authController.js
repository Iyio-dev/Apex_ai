import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import asyncHandler from "../utils/asyncHandler.js";


const generateToken = (userId) => {
    jwt.sign(
        { id: userId},
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
    )
}

const register = asyncHandler(async (req, res) => {
    const { name, email, password, bio } = req.body;

    const existingUser = User.findOne({ email });

    if (existingUser){
        return res.status(401).json()
    }
});