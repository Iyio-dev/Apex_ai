import express from "express";

const app = express();

app.use(express.json());

app.get("/health", (req, res) => {
  res.send("Health check passed!");
});

export default app;